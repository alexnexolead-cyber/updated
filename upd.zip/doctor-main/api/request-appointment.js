const CLINICS = {
  "iqra-unit-one": {
    name: "Iqra Medical Complex — Unit One",
    days: [1, 2, 3, 4, 5, 6],
    time: "6:00 PM – 9:00 PM"
  },
  "farooq-dha": {
    name: "Farooq Hospital — DHA",
    days: [2, 4],
    time: "3:00 PM – 5:00 PM"
  },
  "farooq-allama-iqbal-town": {
    name: "Farooq Hospital — Allama Iqbal Town",
    days: [1, 3, 6],
    time: "3:00 PM – 5:00 PM"
  }
};

const response = (res, status, body) => res.status(status).json(body);

const karachiDate = () => {
  const parts = new Intl.DateTimeFormat("en", {
    timeZone: "Asia/Karachi",
    year: "numeric",
    month: "2-digit",
    day: "2-digit"
  }).formatToParts(new Date());
  const values = Object.fromEntries(parts.map(({ type, value }) => [type, value]));
  return `${values.year}-${values.month}-${values.day}`;
};

const isValidDate = (value) => {
  if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const date = new Date(`${value}T00:00:00.000Z`);
  return !Number.isNaN(date.valueOf()) && date.toISOString().slice(0, 10) === value;
};

module.exports = async function requestAppointment(req, res) {
  if (req.method !== "POST") {
    res.setHeader("Allow", "POST");
    return response(res, 405, { error: "Use POST to submit an appointment request." });
  }

  const { RESEND_API_KEY, RESEND_FROM_EMAIL, SITE_ORIGIN } = process.env;
  if (!RESEND_API_KEY || !RESEND_FROM_EMAIL || !SITE_ORIGIN) {
    console.error("Appointment service is missing required server configuration.");
    return response(res, 503, { error: "Online requests are temporarily unavailable. Please call 0312-4165202." });
  }

  let allowedOrigin;
  try {
    allowedOrigin = new URL(SITE_ORIGIN).origin;
  } catch {
    console.error("SITE_ORIGIN must be a valid absolute URL.");
    return response(res, 503, { error: "Online requests are temporarily unavailable. Please call 0312-4165202." });
  }

  if (req.headers.origin !== allowedOrigin) {
    return response(res, 403, { error: "This request could not be verified. Please reload the page and try again." });
  }

  let body = req.body;
  if (typeof body === "string") {
    if (Buffer.byteLength(body) > 2048) {
      return response(res, 413, { error: "Please shorten the form and try again." });
    }
    try {
      body = JSON.parse(body);
    } catch {
      return response(res, 400, { error: "Please check the form and try again." });
    }
  }
  if (!body || typeof body !== "object" || Array.isArray(body) || Buffer.byteLength(JSON.stringify(body)) > 2048) {
    return response(res, 400, { error: "Please check the form and try again." });
  }
  if (typeof body.website === "string" && body.website.trim()) {
    return response(res, 400, { error: "This request could not be verified. Please check the form and try again." });
  }

  const name = typeof body.name === "string" ? body.name.trim() : "";
  const phone = typeof body.phone === "string" ? body.phone.trim() : "";
  const phoneDigits = phone.replace(/\D/g, "").length;
  const clinic = CLINICS[body.clinic];
  const appointmentDate = body.date;
  const appointmentTime = body.time;

  if (
    name.length < 2 ||
    name.length > 100 ||
    /[\r\n<>]/.test(name) ||
    !/^[+()\d\s-]{7,20}$/.test(phone) ||
    phoneDigits < 7 ||
    phoneDigits > 15 ||
    !clinic ||
    !isValidDate(appointmentDate) ||
    appointmentDate < karachiDate() ||
    appointmentTime !== clinic.time ||
    body.consent !== true
  ) {
    return response(res, 400, { error: "Check your name, phone, location, date, and consent. The selected date and clinic hours must match." });
  }

  const weekday = new Date(`${appointmentDate}T00:00:00.000Z`).getUTCDay();
  if (!clinic.days.includes(weekday)) {
    return response(res, 400, { error: "The selected hospital is not open for appointments on that day. Choose another date." });
  }

  const message = [
    "A new appointment request was submitted through the clinic website.",
    "",
    `Patient name: ${name}`,
    `Phone: ${phone}`,
    `Preferred hospital: ${clinic.name}`,
    `Preferred date: ${appointmentDate}`,
    `Consultation window: ${clinic.time}`,
    "",
    "This is a request only; the appointment has not been confirmed."
  ].join("\n");

  try {
    const emailResponse = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${RESEND_API_KEY}`,
        "Content-Type": "application/json"
      },
      signal: AbortSignal.timeout(10000),
      body: JSON.stringify({
        from: RESEND_FROM_EMAIL,
        to: ["bilal.smm007@gmail.com"],
        subject: "New clinic appointment request",
        text: message
      })
    });

    if (!emailResponse.ok) {
      console.error(`Appointment email provider returned HTTP ${emailResponse.status}.`);
      return response(res, 502, { error: "We couldn't send your request. Please try again or call 0312-4165202." });
    }
  } catch (error) {
    console.error("Appointment email delivery request failed.", error);
    return response(res, 502, { error: "We couldn't send your request. Please try again or call 0312-4165202." });
  }

  return response(res, 202, {
    message: "Your request was sent to the clinic. The team will contact you to confirm availability; this is not a confirmed appointment."
  });
};
